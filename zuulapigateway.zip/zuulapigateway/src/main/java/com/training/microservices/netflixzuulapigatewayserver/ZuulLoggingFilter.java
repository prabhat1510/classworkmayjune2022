package com.training.microservices.netflixzuulapigatewayserver;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

import feign.FeignException;

/**
 * filtering unauthenticated requests
 * @author insignia
 *
 */
@Component
public class ZuulLoggingFilter extends ZuulFilter {

	@Autowired
	private AuthticateProxy aprxy;

	@Override
	public boolean shouldFilter() {
		HttpServletRequest request = RequestContext.getCurrentContext().getRequest();
		System.out.println(request.getRequestURI());
		if(request.getRequestURI().equals("/oauth/oauth/token") || request.getRequestURI().equals("/oauth/oauth/check_token")){
			return false;
		}
		return true;
	}

	@Override
	public Object run() {
		HttpServletRequest request = RequestContext.getCurrentContext().getRequest();
		if (request.getHeader("Authorization") == null) {
			setFailedRequest("No Authoriration Header Provided in request", 401);
			return null;
		}
		try {
			ResponseEntity<?> response = aprxy.fun(request.getHeader("Authorization"), request.getHeader("token"));
		}
		catch (Exception e) {

			setFailedRequest("Authentication failed: Invalid token or Unauthorized", 401);
		}

		

		return null;
	}

	@Override
	public String filterType() {
		return "pre";
	}

	@Override
	public int filterOrder() {
		return 1;
	}

	private void setFailedRequest(String body, int code) {
		// log.debug("Reporting error ({}): {}", code, body);
		RequestContext ctx = RequestContext.getCurrentContext();
		ctx.setResponseStatusCode(code);
		if (ctx.getResponseBody() == null) {
			ctx.setResponseBody(body);
			ctx.setSendZuulResponse(false);
		}
	}
}
