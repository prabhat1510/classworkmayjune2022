package com.training.microservices.netflixzuulapigatewayserver;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
/**
 * making a feign call to oauth server
 * @author insignia
 *
 */
@FeignClient(name = "oauth")
@RibbonClient(name = "oauth")
public interface AuthticateProxy {
	@GetMapping("/oauth/check_token")
	public ResponseEntity<?> fun(@RequestHeader("Authorization") String authHeader,
			@RequestParam("token") String token);

}
