Acceptance Criteria:

1) Integrate Zuul API gateway service in the existing netflix architecture.
2) Implement prefiltration of requests to allow only authenticated (with valid Oauth2 token) requests to microservices.
3) Implement a proper response for unauthenticated requests.
